# plugin.video.vavooto
michaz - version="6.5"
edit kasi - version="6.5.1"
- change menu "live" 
- add "live - A bis Z"

![live](https://raw.githubusercontent.com/kasi45/plugin.video.vavooto/refs/heads/master/live.JPG)
